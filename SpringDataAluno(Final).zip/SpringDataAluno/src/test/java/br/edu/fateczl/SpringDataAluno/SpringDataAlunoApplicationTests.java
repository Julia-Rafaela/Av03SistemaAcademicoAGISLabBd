package br.edu.fateczl.SpringDataAluno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataAlunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
